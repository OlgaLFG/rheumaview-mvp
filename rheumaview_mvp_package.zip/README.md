
# RheumaView™ – Radiologic Reasoning for Rheumatologists

This is the MVP prototype of RheumaView™, a structured radiology interpretation tool designed specifically for rheumatologists.

## To run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
